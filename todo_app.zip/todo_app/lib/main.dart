import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

// ✅ Task Model
class Task {
  String title;
  DateTime date;
  bool isDone;
  Task({required this.title, required this.date, this.isDone = false});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do App',
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/auth': (context) => AuthScreen(),
        '/todo': (context) => ToDoScreen(),
      },
    );
  }
}

// ✅ Common Background Widget
Widget buildBackground(String imagePath) {
  return Stack(
    children: [
      Positioned.fill(
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
        ),
      ),
      Positioned.fill(
        child: Container(
          color: const Color.fromARGB(255, 240, 105, 150).withOpacity(0.2), // Dark overlay
        ),
      ),
    ],
  );
}

// ✅ Home Screen
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          buildBackground('assets/home.jpg'), // Add your image in assets
          Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.task_alt, size: 100, color: Colors.white),
                  SizedBox(height: 20),
                  Text(
                    'Welcome to To-Do App',
                    style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.9),
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    ),
                    onPressed: () => Navigator.pushNamed(context, '/auth'),
                    child: Text('Get Started', style: TextStyle(color: Colors.deepPurple, fontSize: 18)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ✅ Auth Screen
class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLogin = true;
  final _formKey = GlobalKey<FormState>();
  String username = '';
  String password = '';

  void _submit() {
    if (_formKey.currentState!.validate()) {
      Navigator.pushReplacementNamed(context, '/todo');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          buildBackground('assets/login.jpg'),
          Center(
            child: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Text(isLogin ? 'Login' : 'Sign Up', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      SizedBox(height: 20),
                      TextFormField(
                        decoration: InputDecoration(labelText: 'Username', border: OutlineInputBorder()),
                        validator: (value) => value!.isEmpty ? 'Enter username' : null,
                        onChanged: (val) => username = val,
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        obscureText: true,
                        decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
                        validator: (value) => value!.isEmpty ? 'Enter password' : null,
                        onChanged: (val) => password = val,
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _submit,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15)),
                        child: Text(isLogin ? 'Login' : 'Sign Up', style: TextStyle(color: Colors.white)),
                      ),
                      TextButton(
                        onPressed: () => setState(() => isLogin = !isLogin),
                        child: Text(isLogin ? 'Create an account' : 'Already have an account? Login'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ✅ ToDo Screen
class ToDoScreen extends StatefulWidget {
  @override
  _ToDoScreenState createState() => _ToDoScreenState();
}

class _ToDoScreenState extends State<ToDoScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Task> _tasks = [];

  void _addTask(String title) {
    if (title.trim().isEmpty) return;
    setState(() {
      _tasks.add(Task(title: title, date: DateTime.now()));
      _controller.clear();
    });
  }

  void _toggleTaskDone(int index) {
    setState(() {
      _tasks[index].isDone = !_tasks[index].isDone;
    });
  }

  void _deleteTask(int index) {
    setState(() {
      _tasks.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    int completedTasks = _tasks.where((task) => task.isDone).length;

    return Scaffold(
      body: Stack(
        children: [
          buildBackground('assets/landing.jpg'),
          Column(
            children: [
              Container(
                padding: EdgeInsets.only(top: 60),
                width: double.infinity,
                height: 150,
                color: Colors.black.withOpacity(0.5), // Overlay for header
                child: Column(
                  children: [
                    Text("To-Do App", style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text("$completedTasks of ${_tasks.length} tasks completed", style: TextStyle(color: Colors.white70, fontSize: 16)),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          labelText: 'What needs to be done?',
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.85),
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () => _addTask(_controller.text),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, padding: EdgeInsets.all(16)),
                      child: Icon(Icons.add, color: Colors.white),
                    )
                  ],
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: _tasks.isEmpty
                    ? Center(child: Text("No tasks added!", style: TextStyle(fontSize: 18, color: Colors.white)))
                    : ListView.builder(
                        itemCount: _tasks.length,
                        itemBuilder: (context, index) {
                          Task task = _tasks[index];
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            child: Container(
                              decoration: BoxDecoration(
                                color: task.isDone ? Colors.green.withOpacity(0.8) : Colors.white.withOpacity(0.9),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: ListTile(
                                leading: Checkbox(
                                  value: task.isDone,
                                  onChanged: (_) => _toggleTaskDone(index),
                                ),
                                title: Text(task.title,
                                    style: TextStyle(fontSize: 18, decoration: task.isDone ? TextDecoration.lineThrough : TextDecoration.none)),
                                subtitle: Text("${task.date.day}/${task.date.month}/${task.date.year}", style: TextStyle(fontSize: 14)),
                                trailing: IconButton(icon: Icon(Icons.delete, color: Colors.red), onPressed: () => _deleteTask(index)),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
